As discussed in the meeting, the DBSCHEMA tool unfortunately does not create the tables correctly.

Therefore please execute these commands.

chmod +x setup_plan.sh
./setup_plan.sh create_staging.sql 02_load_from_excel.sql